/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shapeshootinggame;

import javafx.stage.Stage;
import javafx.scene.Scene;

/**
 *
 * @author andrewding
 */
public class SpriteView {

    Stage primaryStage; 


    public SpriteView(Stage stage) throws Exception {

        this.primaryStage = stage;
    }
    
    public void showView(Scene scene) {
        
        primaryStage.setTitle("Andrew's Game");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }
}    

