/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shapeshootinggame;

import javafx.scene.paint.Color;

/**
 *
 * @author andrewding
 */
public class SpriteModel {

    private final Sprite player;

    public SpriteModel() {
        this.player = new Sprite(300, 650, 40, 40, "player", Color.CRIMSON);
    }

    public Sprite createPlayerFire(int x, int y, String type) {

        return new Sprite(x, y, 5, 20, type + "fire", Color.CRIMSON);
       
    }

    public Sprite createEnemy(int x) {
        return new Sprite(x, 150, 30, 30, "enemy", Color.KHAKI);
    }

    public void setPlayerDead() {
        player.dead = true;
    }

    public Sprite getPlayer() {
        return player;
    }

    public void movePlayerLeft() {
        player.moveLeft();
    }

    public void movePlayerRight() {
        player.moveRight();
    }
}
