/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shapeshootinggame;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 *
 * @author andrewding
 * 
 * 1. Use keyboard keys A and D to move left and right respectively (repeated tapping works better than holding buttons)
 * 
 * 2. Use space bar key to shoot to eliminate enemies above
 * 
 * 3. Added code: Game runs in MVC design pattern now, previously did not in deliverable 1. 
 * 
 * 3. Have not implemented a respawn/lives feature yet (next deliverable)
 * 
 * 4. Decided to keep sprites as shapes
 * 
 * 5. Will implement pause feature as well (next deliverable)
 * 
 * 6. Will also add a loop that creates more shapes once enemies are eliminated.
 * 
 */
public class ShapeShootingGame extends Application {
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        
        SpriteModel model = new SpriteModel();
        SpriteView view = new SpriteView(primaryStage);
        SpriteController controller = new SpriteController(model, view);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
