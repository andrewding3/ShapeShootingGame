/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shapeshootinggame;

import java.util.List;
import java.util.stream.Collectors;
import javafx.animation.AnimationTimer;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;

/**
 *
 * @author scott.ding
 */
public class SpriteController {

    private final SpriteModel model;
    private final SpriteView view;

    private final Pane root;

    private double time = 0;

    public SpriteController(SpriteModel model, SpriteView view) {
        this.model = model;
        this.view = view;
        
        root = new Pane();

        Scene scene = new Scene(createContent());

        scene.setOnKeyPressed(e -> {
            switch (e.getCode()) {

                case A:
                    model.movePlayerLeft();
                    break;
                case D:
                    model.movePlayerRight();
                    break;
                case SPACE:
                    shoot(model.getPlayer());
                    break;

            }

        });
        view.showView(scene);
    }

    private Parent createContent() {

        root.setPrefSize(600, 900);

        root.getChildren().add(model.getPlayer());

        AnimationTimer timer = new AnimationTimer() {

            @Override
            public void handle(long now) {

                update();

            }

        };

        timer.start();

        nextLevel();

        return root;

    }

    private void nextLevel() {
        for (int i = 0; i < 5; i++) {

            Sprite s = model.createEnemy(90 + i * 100);

            root.getChildren().add(s);
        }

    }

    private List<Sprite> sprites() {
        return root.getChildren().stream().map(n -> (Sprite) n).collect(Collectors.toList());

    }

    private void shoot(Sprite spr) {

        Sprite s = model.createPlayerFire((int) spr.getTranslateX() + 20, (int) spr.getTranslateY(), spr.type);

        root.getChildren().add(s);
    }

    private void update() {

        time += .1;

        sprites().forEach(s -> {

            switch (s.type) {

                case "enemyfire":
                    s.moveUp();

                    if (s.getBoundsInParent().intersects(model.getPlayer().getBoundsInParent())) {

                        model.setPlayerDead();
                        s.dead = true;

                    }
                    break;

                case "playerfire":
                    s.moveDown();
                    sprites().stream().filter(e -> e.type.equals("enemy")).forEach(enemy -> {
                        if (s.getBoundsInParent().intersects(enemy.getBoundsInParent())) {
                            enemy.dead = true;
                            s.dead = true;
                        }
                    });

                    break;

                case "enemy":
                    if (time > 2) {
                        if (Math.random() < 0.3) {

                            shoot(s);
                        }

                    }
                    break;
            }

        });

        root.getChildren().removeIf(n -> {
            Sprite s = (Sprite) n;
            return s.dead;

        });

        if (time > 2) {

            time = 0;
        }
    }

}
