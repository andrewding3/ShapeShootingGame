/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shapeshootinggame;

import javafx.scene.paint.Color;
import javafx.scene.shape.*;

/**
 *
 * @author andrewding
 * 
 * 
 */
public class Sprite extends Rectangle {

    boolean dead = false;
    final String type;

    public Sprite(int x, int y, int w, int h, String type, Color color) {

        super(w, h, color);
        this.type = type;
        setTranslateX(x);
        setTranslateY(y);
    }

    public void moveLeft() {

        setTranslateX(getTranslateX() - 10);

    }

    public void moveRight() {

        setTranslateX(getTranslateX() + 10);

    }

    public void moveUp() {

        setTranslateY(getTranslateY() + 5);
    }

    public void moveDown() {

        setTranslateY(getTranslateY() - 5);
    }

    public void setDead(boolean dead) {
        this.dead = dead;
    }
}
